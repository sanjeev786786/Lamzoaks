jQuery( function() {
    jQuery( "#ad_date" ).datepicker();
    jQuery( "#ad_expiryDate" ).datepicker();
  } );
/* by zaheer */
jQuery( function() {
    jQuery( "#accordion" ).accordion();
  } );
/* end by zaheer */